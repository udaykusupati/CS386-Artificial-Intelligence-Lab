import sys
import numpy as np
from copy import deepcopy
with open(sys.argv[1], "r") as f:
	data=f.read() 
words=data.split()
S=int(words[0])
A=int(words[1])
T=np.zeros((S,A,S))
R=np.zeros((S,A,S))
g=float(words[-1])
p=2
q=2+S*S*A
for i in range(0,S):
	for j in range(0,A):
		for k in range(0,S):
			R[i,j,k]=float(words[p])
			T[i,j,k]=float(words[q])
			p=p+1
			q=q+1
V=np.zeros(S)
Vprev=np.zeros(S)
eps=pow(10,-16)
t=0
while(True):
	for s in range(0,S):
		temp=np.zeros(A)
		for a in range(0,A):
			for s1 in range(0,S):
				temp[a]=temp[a]+T[s,a,s1]*(R[s,a,s1]+g*Vprev[s1])
		V[s]=np.amax(temp)
	t=t+1
	if(np.amax(abs(V-Vprev))<=eps):
		break
	Vprev=deepcopy(V)

Q=np.zeros((S,A))
for s in range(0,S):
	for a in range(0,A):
		for s1 in range(0,S):
			Q[s,a]=Q[s,a]+T[s,a,s1]*(R[s,a,s1]+g*V[s1])
pi=np.zeros(S)
for s in range(0,S):
	pi[s]=np.argmax(Q[s])
for i in range(0,S):
	print V[i],int(pi[i])
print t